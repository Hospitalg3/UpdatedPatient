package com.hospital.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="doctor")
public class Doctor {

	@Id
	@GeneratedValue
    @Column(name="d_id")
	private int d_id;
	@Column(name="d_name")
	private String d_name;
	@Column(name="Gender")
	private String Gender;
	@Column(name="d_password")
	private String d_password;
	@Column(name="mail_id")
	private String mail_id;
	@Column(name="Contact_No")
	private int Contact_No;
	@Column(name="Address")
	private String Address;
	@Column(name="Schedule")
	private String Schedule;
	@Column(name="Specialization")
	private String Specialization;
	public Doctor(String d_name,int d_id, String Gender,String d_password, String mail_id,int Contact_No, String Address, String Schedule, String Specialization) {
        super();
        this.d_name = d_name;
        this.d_id = d_id;
        this.Gender = Gender;
        this.d_password = d_password;
        this.mail_id = mail_id;
        this.Contact_No = Contact_No;
        this.Address = Address;
        this.Schedule = Schedule;
        this.Specialization = Specialization;
  
	}
	public Doctor() {
		
	}
	public int getD_id() {
		return d_id;
	}
	public void setD_id(int d_id) {
		this.d_id = d_id;
	}
	public String getD_name() {
		return d_name;
	}
	public void setD_name(String d_name) {
		this.d_name = d_name;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getD_password() {
		return d_password;
	}
	public void setD_password(String d_password) {
		this.d_password = d_password;
	}
	public String getMail_id() {
		return mail_id;
	}
	public void setMail_id(String mail_id) {
		this.mail_id = mail_id;
	}
	public int getContact_No() {
		return Contact_No;
	}
	public void setContact_No(int contact_No) {
		Contact_No = contact_No;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getSchedule() {
		return Schedule;
	}
	public void setSchedule(String schedule) {
		Schedule = schedule;
	}
	public String getSpecialization() {
		return Specialization;
	}
	public void setSpecialization(String specialization) {
		Specialization = specialization;
	}
	
}
   

